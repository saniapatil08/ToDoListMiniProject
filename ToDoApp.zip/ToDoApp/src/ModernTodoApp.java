import java.awt.*;
import java.sql.*;
import javax.swing.*;

public class ModernTodoApp extends JFrame {
    private JTextField taskField;
    private DefaultListModel<String> listModel;
    private JList<String> todoList;
    private Connection conn;

    public ModernTodoApp() {
        setupUI();
        setupDatabase();
        loadTodos();
    }

    private void setupDatabase() {
        try {
            Class.forName("org.sqlite.JDBC");
            conn = DriverManager.getConnection("jdbc:sqlite:todos.db");
            Statement stmt = conn.createStatement();
            stmt.execute(
                "CREATE TABLE IF NOT EXISTS todos (" +
                "id INTEGER PRIMARY KEY AUTOINCREMENT," +
                "task TEXT NOT NULL," +
                "completed BOOLEAN DEFAULT 0)"
            );
        } catch (Exception e) {
            JOptionPane.showMessageDialog(this, "Database Error: " + e.getMessage());
            e.printStackTrace();
        }
    }

    private void setupUI() {
        setTitle("Vibrant Todo List");
        setSize(500, 700);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLayout(new BorderLayout(10, 10));

        // Header Panel
        JPanel headerPanel = new JPanel();
        headerPanel.setBackground(new Color(255, 204, 204)); // Soft pink
        headerPanel.setLayout(new FlowLayout(FlowLayout.CENTER, 10, 10));
        JLabel titleLabel = new JLabel("Vibrant Todo List");
        titleLabel.setFont(new Font("SansSerif", Font.BOLD, 28));
        titleLabel.setForeground(Color.BLACK);
        headerPanel.add(titleLabel);

        // Input Panel
        JPanel inputPanel = new JPanel(new FlowLayout(FlowLayout.CENTER, 10, 10));
        inputPanel.setBackground(new Color(204, 229, 255)); // Soft blue
        taskField = new JTextField(20);
        taskField.setFont(new Font("SansSerif", Font.PLAIN, 16));
        taskField.setBorder(BorderFactory.createLineBorder(Color.GRAY, 1));
        JButton addButton = createCustomButton("Add Task", new Color(255, 153, 51), new Color(255, 204, 153));
        inputPanel.add(taskField);
        inputPanel.add(addButton);

        // List Panel
        listModel = new DefaultListModel<>();
        todoList = new JList<>(listModel);
        todoList.setFont(new Font("SansSerif", Font.PLAIN, 16));
        todoList.setCellRenderer(new DefaultListCellRenderer()); // Default renderer
        JScrollPane scrollPane = new JScrollPane(todoList);
        scrollPane.setBorder(BorderFactory.createLineBorder(new Color(102, 178, 255), 2));

        // Button Panel
        JPanel buttonPanel = new JPanel(new FlowLayout(FlowLayout.CENTER, 10, 10));
        buttonPanel.setBackground(new Color(255, 229, 204)); // Soft orange
        JButton completeButton = createCustomButton("Complete", new Color(102, 255, 102), new Color(204, 255, 204));
        JButton editButton = createCustomButton("Edit", new Color(255, 255, 102), new Color(255, 255, 204));
        JButton deleteButton = createCustomButton("Delete", new Color(255, 102, 102), new Color(255, 178, 178));
        buttonPanel.add(completeButton);
        buttonPanel.add(editButton);
        buttonPanel.add(deleteButton);

        // Add Panels to Frame
        add(headerPanel, BorderLayout.NORTH);
        add(inputPanel, BorderLayout.NORTH);
        add(scrollPane, BorderLayout.CENTER);
        add(buttonPanel, BorderLayout.SOUTH);

        // Add Listeners
        addButton.addActionListener(e -> addTask());
        completeButton.addActionListener(e -> markComplete());
        editButton.addActionListener(e -> editTask());
        deleteButton.addActionListener(e -> deleteTask());
        taskField.addActionListener(e -> addTask());

        setLocationRelativeTo(null);
        setVisible(true);
    }

    private JButton createCustomButton(String text, Color gradientStart, Color gradientEnd) {
        JButton button = new JButton(text) {
            @Override
            protected void paintComponent(Graphics g) {
                if (!isContentAreaFilled()) {
                    super.paintComponent(g);
                    return;
                }
                Graphics2D g2 = (Graphics2D) g.create();
                g2.setPaint(new GradientPaint(0, 0, gradientStart, getWidth(), getHeight(), gradientEnd));
                g2.fillRect(0, 0, getWidth(), getHeight());
                g2.dispose();
                super.paintComponent(g);
            }
        };
        button.setContentAreaFilled(false);
        button.setOpaque(true);
        button.setForeground(Color.BLACK);
        button.setFont(new Font("SansSerif", Font.BOLD, 14));
        button.setFocusPainted(false);
        return button;
    }

    private void loadTodos() {
        listModel.clear();
        try {
            Statement stmt = conn.createStatement();
            ResultSet rs = stmt.executeQuery("SELECT * FROM todos ORDER BY id DESC");
            while (rs.next()) {
                String task = rs.getString("task");
                boolean completed = rs.getBoolean("completed");
                listModel.addElement((completed ? "✓ " : "") + task);
            }
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(this, "Error loading tasks!");
        }
    }

    private void addTask() {
        String task = taskField.getText().trim();
        if (!task.isEmpty()) {
            try {
                PreparedStatement pstmt = conn.prepareStatement("INSERT INTO todos (task) VALUES (?)");
                pstmt.setString(1, task);
                pstmt.executeUpdate();
                taskField.setText("");
                loadTodos();
            } catch (SQLException e) {
                JOptionPane.showMessageDialog(this, "Error adding task!");
            }
        } else {
            JOptionPane.showMessageDialog(this, "Task cannot be empty!");
        }
    }

    private void markComplete() {
        int selectedIndex = todoList.getSelectedIndex();
        if (selectedIndex != -1) {
            try {
                String task = listModel.get(selectedIndex).replace("✓ ", "");
                PreparedStatement pstmt = conn.prepareStatement("UPDATE todos SET completed = NOT completed WHERE task = ?");
                pstmt.setString(1, task);
                pstmt.executeUpdate();
                loadTodos();
            } catch (SQLException e) {
                JOptionPane.showMessageDialog(this, "Error updating task!");
            }
        } else {
            JOptionPane.showMessageDialog(this, "Select a task to mark complete!");
        }
    }

    private void editTask() {
        int selectedIndex = todoList.getSelectedIndex();
        if (selectedIndex != -1) {
            String oldTask = listModel.get(selectedIndex).replace("✓ ", "");
            String newTask = JOptionPane.showInputDialog(this, "Edit Task:", oldTask);
            if (newTask != null && !newTask.trim().isEmpty()) {
                try {
                    PreparedStatement pstmt = conn.prepareStatement("UPDATE todos SET task = ? WHERE task = ?");
                    pstmt.setString(1, newTask.trim());
                    pstmt.setString(2, oldTask);
                    pstmt.executeUpdate();
                    loadTodos();
                } catch (SQLException e) {
                    JOptionPane.showMessageDialog(this, "Error editing task!");
                }
            }
        } else {
            JOptionPane.showMessageDialog(this, "Select a task to edit!");
        }
    }

    private void deleteTask() {
        int selectedIndex = todoList.getSelectedIndex();
        if (selectedIndex != -1) {
            int confirm = JOptionPane.showConfirmDialog(
                this,
                "Are you sure you want to delete this task?",
                "Confirm Delete",
                JOptionPane.YES_NO_OPTION
            );
            if (confirm == JOptionPane.YES_OPTION) {
                try {
                    String task = listModel.get(selectedIndex).replace("✓ ", "");
                    PreparedStatement pstmt = conn.prepareStatement("DELETE FROM todos WHERE task = ?");
                    pstmt.setString(1, task);
                    pstmt.executeUpdate();
                    loadTodos();
                } catch (SQLException e) {
                    JOptionPane.showMessageDialog(this, "Error deleting task!");
                }
            }
        } else {
            JOptionPane.showMessageDialog(this, "Select a task to delete!");
        }
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(ModernTodoApp::new);
    }
}